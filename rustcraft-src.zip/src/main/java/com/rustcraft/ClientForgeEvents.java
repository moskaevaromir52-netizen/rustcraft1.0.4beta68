package com.rustcraft;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ComputeFovModifierEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Клавиши Z (обвесы) и X (фонарь/лазер), зум прицела при приседе. */
@Mod.EventBusSubscriber(modid = RustCraft.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class ClientForgeEvents {
    private ClientForgeEvents() {
    }

    @SubscribeEvent
    public static void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null) return;
        while (ClientKeys.ATTACH.consumeClick()) {
            if (mc.screen == null && p.getMainHandItem().getItem() instanceof GunItem) {
                mc.setScreen(new AttachmentScreen());
            }
        }
        while (ClientKeys.TOGGLE.consumeClick()) {
            if (p.getMainHandItem().getItem() instanceof GunItem) {
                RustNet.CHANNEL.sendToServer(new AttachPacket(AttachPacket.TOGGLE, ""));
            }
        }
    }

    @SubscribeEvent
    public static void onFov(ComputeFovModifierEvent e) {
        if (!e.getPlayer().isShiftKeyDown()) return;
        ItemStack held = e.getPlayer().getMainHandItem();
        if (!(held.getItem() instanceof GunItem)) return;
        float z = Attachments.mods(held).zoom();
        if (z < 1.0F) e.setNewFovModifier(e.getNewFovModifier() * z);
    }
}
