package com.rustcraft;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

import java.util.List;

/** Экран верстака: сетка оружия/компонентов слева, описание и кнопки справа. */
public class WorkbenchScreen extends AbstractContainerScreen<WorkbenchMenu> {
    private static final int COLS = 8;
    private static final int CELL = 20;
    private static final int GX = 8;
    private static final int GY = 46;
    private static final int[] TIER_COLOR = {0, 0xFF7FBF5A, 0xFF5A9BD5, 0xFFB86FD6};

    private int tab = 0;
    private int selected = -1;
    private Button tabWeapons;
    private Button tabAttach;
    private Button tabSupplies;
    private Button action;
    private Button upgrade;

    public WorkbenchScreen(WorkbenchMenu menu, Inventory inv, Component title) {
        super(menu, inv, title);
        this.imageWidth = 304;
        this.imageHeight = 212;
    }

    private List<WeaponTree.Entry> list() {
        return tab == 0 ? WeaponTree.WEAPONS : (tab == 1 ? WeaponTree.ATTACHMENTS : WeaponTree.SUPPLIES);
    }

    private WeaponTree.Entry sel() {
        List<WeaponTree.Entry> l = list();
        return selected >= 0 && selected < l.size() ? l.get(selected) : null;
    }

    @Override
    protected void init() {
        super.init();
        tabWeapons = addRenderableWidget(Button.builder(Component.translatable("gui.rustcraft.tab_weapons"), b -> {
            tab = 0;
            selected = -1;
        }).bounds(leftPos + 8, topPos + 20, 52, 20).build());
        tabAttach = addRenderableWidget(Button.builder(Component.translatable("gui.rustcraft.tab_attach"), b -> {
            tab = 1;
            selected = -1;
        }).bounds(leftPos + 62, topPos + 20, 52, 20).build());
        tabSupplies = addRenderableWidget(Button.builder(Component.translatable("gui.rustcraft.tab_supplies"), b -> {
            tab = 2;
            selected = -1;
        }).bounds(leftPos + 116, topPos + 20, 56, 20).build());
        action = addRenderableWidget(Button.builder(Component.empty(), b -> {
            WeaponTree.Entry e = sel();
            if (e == null) return;
            boolean research = e.kind() == WeaponTree.Kind.WEAPON && !menu.isResearched(e);
            click(WorkbenchMenu.code(research ? WorkbenchMenu.ACT_RESEARCH : WorkbenchMenu.ACT_CRAFT,
                    WeaponTree.ALL.indexOf(e)));
        }).bounds(leftPos + 180, topPos + 184, 116, 20).build());
        upgrade = addRenderableWidget(Button.builder(Component.empty(), b ->
                click(WorkbenchMenu.code(WorkbenchMenu.ACT_UPGRADE, 0))
        ).bounds(leftPos + 8, topPos + 176, 162, 20).build());
        updateButtons();
    }

    private void click(int code) {
        if (minecraft != null && minecraft.gameMode != null) {
            minecraft.gameMode.handleInventoryButtonClick(menu.containerId, code);
        }
    }

    private boolean creative() {
        return minecraft != null && minecraft.player != null && minecraft.player.getAbilities().instabuild;
    }

    private int scrapCount() {
        return minecraft == null || minecraft.player == null ? 0
                : InvUtil.count(minecraft.player, ModItems.SCRAP.get());
    }

    private boolean hasCost(WeaponTree.Entry e) {
        if (creative()) return true;
        for (WeaponTree.Ing ing : e.cost()) {
            if (InvUtil.count(minecraft.player, WeaponTree.item(ing.item())) < ing.count()) return false;
        }
        return true;
    }

    private void updateButtons() {
        if (action == null) return;
        tabWeapons.active = tab != 0;
        tabAttach.active = tab != 1;
        tabSupplies.active = tab != 2;

        WeaponTree.Entry e = sel();
        if (e == null) {
            action.active = false;
            action.setMessage(Component.translatable("gui.rustcraft.select"));
        } else {
            boolean tierOk = menu.tier() >= e.tier();
            if (e.kind() == WeaponTree.Kind.WEAPON && !menu.isResearched(e)) {
                action.setMessage(Component.translatable("gui.rustcraft.research", e.scrap()));
                action.active = tierOk && (creative() || scrapCount() >= e.scrap());
            } else {
                action.setMessage(Component.translatable("gui.rustcraft.craft"));
                action.active = tierOk && hasCost(e);
            }
        }

        int t = menu.tier();
        if (t >= 3) {
            upgrade.setMessage(Component.translatable("gui.rustcraft.max_level"));
            upgrade.active = false;
        } else {
            int cost = RustBalance.UPGRADE_SCRAP[t + 1];
            upgrade.setMessage(Component.translatable("gui.rustcraft.upgrade", t + 1, cost));
            upgrade.active = creative() || scrapCount() >= cost;
        }
    }

    @Override
    protected void containerTick() {
        super.containerTick();
        updateButtons();
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        int cx = (int) (mx - leftPos - GX);
        int cy = (int) (my - topPos - GY);
        if (cx >= 0 && cy >= 0 && cx < COLS * CELL && cy < 6 * CELL) {
            int idx = (cy / CELL) * COLS + cx / CELL;
            if (idx < list().size()) {
                selected = idx;
                updateButtons();
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    protected void renderBg(GuiGraphics g, float pt, int mx, int my) {
        int x = leftPos;
        int y = topPos;
        g.fill(x - 2, y - 2, x + imageWidth + 2, y + imageHeight + 2, 0xFF3A3F45);
        g.fill(x, y, x + imageWidth, y + imageHeight, 0xFF1B1D20);
        g.fill(x + 174, y + 18, x + imageWidth - 6, y + 208, 0xFF23262A);

        g.drawString(font, this.title, x + 8, y + 7, 0xFFE0A030, false);
        g.drawString(font, Component.translatable("gui.rustcraft.level", menu.tier()),
                x + imageWidth - 8 - font.width(Component.translatable("gui.rustcraft.level", menu.tier())),
                y + 7, 0xFFBBBBBB, false);

        // сетка
        List<WeaponTree.Entry> l = list();
        for (int i = 0; i < COLS * 6; i++) {
            int sx = x + GX + (i % COLS) * CELL;
            int sy = y + GY + (i / COLS) * CELL;
            g.fill(sx, sy, sx + CELL - 1, sy + CELL - 1, 0xFF2D3035);
            if (i >= l.size()) continue;
            WeaponTree.Entry e = l.get(i);
            int col = TIER_COLOR[e.tier()];
            g.fill(sx, sy, sx + CELL - 1, sy + 1, col);
            g.renderItem(WeaponTree.stack(e), sx + 1, sy + 1);
            boolean locked = menu.tier() < e.tier();
            if (locked) g.fill(sx, sy, sx + CELL - 1, sy + CELL - 1, 0xAA000000);
            if (e.kind() == WeaponTree.Kind.WEAPON && menu.isResearched(e)) {
                g.drawString(font, "\u2714", sx + CELL - 9, sy + CELL - 10, 0xFF55FF55, true);
            }
            if (i == selected) {
                int c = 0xFFFFFFFF;
                g.fill(sx - 1, sy - 1, sx + CELL, sy, c);
                g.fill(sx - 1, sy + CELL - 1, sx + CELL, sy + CELL, c);
                g.fill(sx - 1, sy, sx, sy + CELL - 1, c);
                g.fill(sx + CELL - 1, sy, sx + CELL, sy + CELL - 1, c);
            }
        }

        g.drawString(font, Component.translatable("gui.rustcraft.scrap", scrapCount()), x + 8, y + 200, 0xFFD9A31C, false);
        renderDetails(g, x, y);
    }

    private void renderDetails(GuiGraphics g, int x, int y) {
        WeaponTree.Entry e = sel();
        int dx = x + 180;
        if (e == null) {
            g.drawWordWrap(font, Component.translatable("gui.rustcraft.hint"), dx, y + 26, 110, 0xFFAAAAAA);
            return;
        }
        ItemStack st = WeaponTree.stack(e);
        g.pose().pushPose();
        g.pose().translate(dx, y + 24, 0);
        g.pose().scale(2.0F, 2.0F, 1.0F);
        g.renderItem(st, 0, 0);
        g.pose().popPose();

        List<FormattedCharSequence> name = font.split(FormattedText.of(st.getHoverName().getString()), 76);
        for (int i = 0; i < name.size() && i < 3; i++) {
            g.drawString(font, name.get(i), dx + 38, y + 24 + i * 10, 0xFFFFFFFF, false);
        }
        g.drawString(font, Component.translatable("gui.rustcraft.tier", e.tier()), dx, y + 60, TIER_COLOR[e.tier()], false);

        Component status;
        int sc;
        if (menu.tier() < e.tier()) {
            status = Component.translatable("gui.rustcraft.need_bench", e.tier());
            sc = 0xFFFF5555;
        } else if (e.kind() == WeaponTree.Kind.WEAPON && !menu.isResearched(e)) {
            status = Component.translatable("gui.rustcraft.not_researched", e.scrap());
            sc = 0xFFFFAA00;
        } else {
            status = Component.translatable("gui.rustcraft.ready");
            sc = 0xFF55FF55;
        }
        g.drawString(font, status, dx, y + 71, sc, false);

        g.drawString(font, Component.translatable("gui.rustcraft.cost", e.outCount()), dx, y + 86, 0xFFBBBBBB, false);
        int ry = y + 98;
        for (WeaponTree.Ing ing : e.cost()) {
            Item it = WeaponTree.item(ing.item());
            ItemStack is = new ItemStack(it);
            g.renderItem(is, dx, ry - 4);
            int have = creative() || minecraft == null || minecraft.player == null ? ing.count()
                    : InvUtil.count(minecraft.player, it);
            int col = have >= ing.count() ? 0xFF55FF55 : 0xFFFF5555;
            String nm = is.getHoverName().getString();
            if (font.width(nm) > 64) nm = font.plainSubstrByWidth(nm, 60) + "..";
            g.drawString(font, nm, dx + 18, ry - 3, 0xFFDDDDDD, false);
            g.drawString(font, have + "/" + ing.count(), dx + 18, ry + 6, col, false);
            ry += 17;
        }
    }

    @Override
    protected void renderLabels(GuiGraphics g, int mx, int my) {
        // подписи рисуются в renderBg
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        super.render(g, mx, my, pt);
        int cx = mx - leftPos - GX;
        int cy = my - topPos - GY;
        if (cx >= 0 && cy >= 0 && cx < COLS * CELL && cy < 6 * CELL) {
            int idx = (cy / CELL) * COLS + cx / CELL;
            if (idx < list().size()) {
                g.renderTooltip(font, WeaponTree.stack(list().get(idx)), mx, my);
            }
        }
    }
}
